//
//  LocationManager.swift
//  techne
//
//  Created by Nicholas LoGioco on 3/22/17.
//  Copyright © 2017 Tekton Technologies. All rights reserved.
//

import Foundation
import CoreLocation
import ContactsUI

protocol LocationManagerDelegate {
    func locationFound(withCoordinates coordinates : CLLocationCoordinate2D)
}

class LocationManager : NSObject {
    private static let sharedInstance = LocationManager()
    
    public var manager : CLLocationManager?
    var delegate : LocationManagerDelegate!
    
    func setManager() {
        manager = CLLocationManager()
        manager?.delegate = self
        manager?.desiredAccuracy = kCLLocationAccuracyBest
        
        if isAuthorized() {
            manager?.startUpdatingLocation()
        }else{
            manager?.requestWhenInUseAuthorization()
        }
    }
    
    func isAuthorized() -> Bool {
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            return true
        } else {
            return false
        }
    }
    
    func removeManager() {
        if manager != nil {
            manager?.stopUpdatingLocation()
            manager = nil
        }
    }
    
    func coordinatesToAddress(withCoordinates coordinates : CLLocationCoordinate2D, withCompletionBlock completionBlock : @escaping (_ city : String?, _ state : String?) -> ()) {
        let location = CLLocation(latitude: coordinates.latitude, longitude: coordinates.longitude)
        let geoCoder = CLGeocoder()
        geoCoder.reverseGeocodeLocation(location) { (placemarks, error) in
            var cityBlock : String!
            var stateBlock : String!
            if let placemark = placemarks?.first {
                if let dict = placemark.addressDictionary {
                    if let city = dict["City"] {
                        cityBlock = city as? String
                    }
                    if let state = dict["State"] {
                        stateBlock = state as? String
                    }
                }
            }
            completionBlock(cityBlock, stateBlock)
        }
    }
    
    func addressToCoordinatesConverter(address: String) {
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString("24682 Footed Ridge Ter, Sterling, VA 20166") { (placemark, error) in
            print("placemark: \(String(describing: placemark))")
            if let mark = placemark?.first {
                print("coord: \(String(describing: mark.location))")
            }
        }
    }
    
}

extension LocationManager : CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let lastLocation = locations.last {
            self.delegate.locationFound(withCoordinates: lastLocation.coordinate)
            self.removeManager()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Failed to initialize GPS: \(error.localizedDescription)")
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .notDetermined:
            print("NotDetermined")
        case .restricted:
            print("Restricted")
        case .denied:
            print("Denied")
            if let settingUrl = URL(string: UIApplicationOpenSettingsURLString){
                UIApplication.shared.open(settingUrl)
            }
        case .authorizedAlways:
            print("AuthorizedAlways")
        case .authorizedWhenInUse:
            print("AuthorizedWhenInUse")
            manager.startUpdatingLocation()
        }
    }
}
