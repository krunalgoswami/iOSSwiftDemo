enum enumMultipartDataType {
    case Image
    case Video
    case Audio
    case File
    case Document
    
    var value : String {
        switch self{
        case .Image: return "image"
        case .Video: return "video"
        case .Audio: return "audio"
        case .File: return "file"
        case .Document: return "document"
        }
    }
}


enum enumBackGroundType {
    case SplashBanner,HomeBanner, SignUpBackground, SignUpSelectOneBackground,SignUpGenreBackground,SplashView,SplashAnimatedBanner
    var value:String{
        switch self {
        case .SplashBanner:
            return "splashBanner"
        case .SplashAnimatedBanner:
            return "splashAnimatedBanner"
        case .HomeBanner:
            return "homeBanner"
        case .SignUpBackground:
            return "signUpBackground"
        case .SignUpSelectOneBackground:
            return "signUpSelectOneBackground"
        case .SignUpGenreBackground:
            return "signUpGenreBackground"
        case .SplashView:
            return "SplashView"
        }
    }
}


enum enumBackGroundImageFolderName {
    case SplashBanner,HomeBanner, SignUpBackground, SignUpSelectOneBackground,SignUpGenreBackground,SplashView,SplashAnimatedBanner
    var value:String{
        switch self {
        case .SplashBanner:
            return "splashBanner"
        case .SplashAnimatedBanner:
            return "splashAnimatedBanner"
        case .HomeBanner:
            return "BannerImage"
        case .SignUpBackground:
            return "SignUpPersonalImage"
        case .SignUpSelectOneBackground:
            return "SignUpSelection"
        case .SignUpGenreBackground:
            return "SignUpProfessionOrPreferences"
        case .SplashView:
            return "SplashView"
        }
    }
}


enum enumMultipartDataMimeType {
    case ImagePng
    case ImageJpg
    case AudioAac
    case AdobePhotoshopFile
    case AdobeIllustratorFile
    
    var value : String {
        switch self{
        case .ImagePng: return "image/png"
        case .ImageJpg: return "image/jpeg"
        case .AudioAac: return "audio/aac"
        case .AdobePhotoshopFile: return "image/vnd.adobe.photoshop"
        case .AdobeIllustratorFile: return "application/illustrator"
        }
    }
}

enum enumImageOrFileType {
    case Profile
    case Art
    case Chat
    case IDImage
    case AdobePhotoShopFile
    case AdobeIllustratorFile
    
    var value : String {
        switch self{
        case .Profile: return "IMGPROFILE"
        case .Art: return "IMGART"
        case .Chat: return "IMGCHAT"
        case .IDImage: return "IMGID"
        case .AdobePhotoShopFile: return "ADOBEPHOTOSHOPFILE"
        case .AdobeIllustratorFile: return "ADOBEILLUSTRATORFILE"
        }
    }
}

enum enumFromScreenSubType {
    case loginArtDetail,SignUpArtDetail, Profile,None
}

enum enumRootDestinationType {
    case Gallery, LiveChat, Notification, BuyProduct, None
}
