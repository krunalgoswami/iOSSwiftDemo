//
//  SocketIOManager.swift
//  CallStatusDashboard
//
//  Created by smartSense on 22/07/17.
//  Copyright © 2017 Sam Agnew. All rights reserved.
//

import UIKit
import SocketIO
import EVReflection

class SocketIOManager: NSObject {
    
    //MARK:- Variables
    static var sharedInstance = SocketIOManager()
    //    var socket = SocketIOClient(socketURL: URL(string: kUrlApi.BaseUrl)!, config: [.log(false),.reconnects(false),.forcePolling(true),.forceWebsockets(true),.forceNew(true)])
    var socket = SocketIOClient(socketURL: URL(string: kUrlApi.BaseUrl)!, config: [.log(false),.reconnects(false),.forcePolling(true),.forceWebsockets(true)])
    var isWantToConnect = false
    var islastDisconnectTimeShort = false
    var lastDisconnectTime = Date()
    
    //MARK:- Init
    override init() {
        super.init()
        
    }
    
    //MARK:- Connection Methods
    func establishConnection() {
        isWantToConnect =  true
        if let objSocketEngine = SocketIOManager.sharedInstance.socket.engine, objSocketEngine.connected {
            return
        } else {
            socket.connect()
        }
    }
    
    func closeConnection() {
        isWantToConnect =  false
        guard let objSocketEngine = SocketIOManager.sharedInstance.socket.engine, objSocketEngine.connected else{
            return
        }
        socket.disconnect()
    }
    
    func reestablishConnection() {
        kStorage.isNetworkIssue = true
        Utility.showProgressHUD(title: kToast.HudTitle.ResolvingNetwork)
        socket.disconnect()
        perform(#selector(self.establishConnection), with: nil, afterDelay: 0.1)
    }
    
    func getConnectTime() -> TimeInterval {
        /* This Calulation is for cover 2 cases
         1) When Internet Offline at that time disconnect method Calls Instantly after establishConnection Call.
         For that i increase connect time 1 second. every second call connect method.
         - now i detect internet case in future this case may be happend by another reason. So for that i am not checking internet available check i make common like lastDisconnectTimeIntervals. any of the reason last disconnect time less or equal to 1 sec. then connect delay time should be 1 sec other wise 0.1 sec
         
         2) islastDisconnectTimeShort - this flag taken for skip 1 time if lastDisconnectTimeIntervals is less or equal to 1 sec. due to cover one case of app goes to background. In future any of the reason manualy wants to make connect time short(0.1) islastDisconnectTimeShort flag is useful
         */
        
        let lastDisconnectTimeIntervals = Date().timeIntervalSince(self.lastDisconnectTime)
        print("lastDisconnectTimeIntervals : \(lastDisconnectTimeIntervals)")
        if lastDisconnectTimeIntervals <= 1000{
            if islastDisconnectTimeShort{
                print("ConnectTime : 1.0")
                return 1.0
            } else {
                islastDisconnectTimeShort = true
                print("ConnectTime : 0.1")
                return 0.1
            }
        } else {
            islastDisconnectTimeShort = false
            print("ConnectTime : 1.0")
            return 1.0
        }
    }
    
    //MARK:- Handlers
    func addBasicHandlers() {
        socket.removeAllHandlers()
        addConnectHandler()
        addDisconnectHandler()
        addReconnectHandler()
        addReconnectAttemptHandler()
        addStatusChangeHandler()
        addErrorHandler()
        
        addJoinRoomHandler()
        addGetConversionHandler()
        addGetLatestMsgHandler()
    }
    
    func addMessgeExchangeHandlers() {
        addSendMessageHandler()
        addReceiveMessageHandler()
        addReadMessageHandler()
    }
    
    func addConnectHandler() {
        socket.on(clientEvent: .connect) { (dataArray, ack) in
            print("Socket Connected Successfully !!! SocketSid : \(self.socket.sid ?? "") Time : \(Date())")
            if kStorage.isNetworkIssue{
                kStorage.isNetworkIssue = false
                Utility.hideProgressHUD()
                Utility.showToastMessage(kToast.General.NetworkConnection)
                CustomDelegates.liveChatDelegate?.networkIssueResolved()
            }
        }
    }
    
    func addDisconnectHandler() {
        socket.on(clientEvent: .disconnect) { (dataArray, ack) in
            print("Socket Disconnected !!! SocketSid : \(self.socket.sid ?? "") Time : \(Date())")
            print("dataArray : \(dataArray)")
            if self.isWantToConnect{
                self.perform(#selector(self.establishConnection), with: nil, afterDelay: self.getConnectTime())
            }
        }
    }
    
    func addReconnectHandler() {
        socket.on(clientEvent: .reconnect) { (dataArray, ack) in
            print("Socket Reconnected !!! SocketSid : \(self.socket.sid ?? "")")
        }
    }
    
    func addReconnectAttemptHandler() {
        socket.on(clientEvent: .reconnectAttempt) { (dataArray, ack) in
            print("Socket Reconnect Attempt !!! SocketSid : \(self.socket.sid ?? "")")
        }
    }
    
    func addStatusChangeHandler() {
        socket.on(clientEvent: .statusChange) { (dataArray, ack) in
            print("Socket StatusChange !!! SocketSid : \(self.socket.sid ?? "")")
        }
    }
    
    func addErrorHandler() {
        socket.on(clientEvent: .error) { (dataArray, ack) in
            print("Socket Error !!! SocketSid : \(self.socket.sid ?? "")")
        }
    }
    
    func addJoinRoomHandler() {
        socket.on(kSocketEvents.JoinRoom) { (dataArray, ack) in
            kStorage.socketID = self.socket.sid ?? ""
            BaseSocket.dataGoblal = AdminDetailData()
            self.manageEvent(eventName: kSocketEvents.JoinRoom, dataArray: dataArray)
        }
    }
    
    func addGetConversionHandler() {
        socket.on(kSocketEvents.GetConversion) { (dataArray, ack) in
            BaseSocket.dataGoblal = ChatHistoryData()
            self.manageEvent(eventName: kSocketEvents.GetConversion, dataArray: dataArray)
        }
    }
    
    func addGetLatestMsgHandler() {
        socket.on(kSocketEvents.GetLatestMsg) { (dataArray, ack) in
            BaseSocket.dataGoblal = ChatHistoryData()
            self.manageEvent(eventName: kSocketEvents.GetLatestMsg, dataArray: dataArray)
        }
    }
    
    func addSendMessageHandler() {
        socket.on(kSocketEvents.SendMessage) { (dataArray, ack) in
            BaseSocket.dataGoblal = MessageDataLiveChat()
            self.manageEvent(eventName: kSocketEvents.SendMessage, dataArray: dataArray)
        }
    }
    
    func addReceiveMessageHandler() {
        socket.on(kSocketEvents.ReceiveMessage) { (dataArray, ack) in
            BaseSocket.dataGoblal = MessageDataLiveChat()
            self.manageEvent(eventName: kSocketEvents.ReceiveMessage, dataArray: dataArray)
        }
    }
    
    func addReadMessageHandler() {
        socket.on(kSocketEvents.ReadMessage) { (dataArray, ack) in
            BaseSocket.dataGoblal = ReadMessageData()
            self.manageEvent(eventName: kSocketEvents.ReadMessage, dataArray: dataArray)
        }
    }
    
    //MARK:- Emit Method
    func emiting(eventName:String, requestData:[String:Any], showHud:Bool = false, timeOut:Bool = false) {
        if !Reachability.isInternetAvailable() {
            Utility.showToastMessage(kToast.General.CheckInternetConnection)
            return
        }
        
        guard let objSocketEngine = SocketIOManager.sharedInstance.socket.engine, objSocketEngine.connected else{
            Utility.showToastMessage(kToast.General.SocketConnection)
            return
        }
        
        if let socketID = self.socket.sid, !socketID.isEmpty, !kStorage.socketID.isEmpty, socketID == kStorage.socketID{
            if showHud{ Utility.showProgressHUD()   }
            print("Emit \(eventName) On SocketSid : \(self.socket.sid ?? "")")
            print("requestData \(requestData)")
            socket.emit(eventName, with: [requestData])
            if timeOut{ Utility.resetTimer(true) }
        } else {
            reestablishConnection()
        }
    }
    
    //MARK:- Event Managers Method
    func manageEvent(eventName:String, dataArray:[Any]) {
        Utility.resetTimer(false)
        Utility.hideProgressHUD()
        if let response = dataArray.first as? NSDictionary{
            let objBaseSocket = BaseSocket(dictionary: response)
            if objBaseSocket.error{
                handleErrorEvent(eventName: eventName, message: objBaseSocket.msg)
            } else {
                handleSuccessEvent(eventName: eventName, dataModel: objBaseSocket.data, pager: objBaseSocket.pager)
            }
        }
    }
    
    func handleErrorEvent(eventName:String, message:String) {
        Utility.showToastMessage(message)
        switch eventName {
        case kSocketEvents.JoinRoom:
            print("Error In JoinRoom Event message : \(message)")
        case kSocketEvents.SendMessage:
            CustomDelegates.liveChatDelegate?.messageReceived(data: nil)
        case kSocketEvents.ReceiveMessage:
            CustomDelegates.liveChatDelegate?.messageReceived(data: nil)
        case kSocketEvents.ReadMessage:
            CustomDelegates.liveChatDelegate?.messageRead(data: nil)
        case kSocketEvents.GetConversion:
            CustomDelegates.liveChatDelegate?.getConversion(chatBasePath: "", data: nil, isPaging: false)
        case kSocketEvents.GetLatestMsg:
            CustomDelegates.liveChatDelegate?.getLatestMsg(data: nil)
        default:
            print("Invalid Event Received!!!")
        }
    }
    
    func handleSuccessEvent(eventName:String, dataModel:EVObject, pager:PagerSocket) {
        switch eventName {
        case kSocketEvents.JoinRoom:
            if kStorage.objUser != nil, !kStorage.objUser.id.isEmpty{
                let requestData = ["userId":kStorage.objUser.id]
                LiveChatServiceSocket.joinRoom(requestData: requestData)
                if !kStorage.isChatLive{
                    let objAdminDetailData = dataModel as! AdminDetailData
                    CustomDelegates.liveChatDelegate?.readyForLiveChat(adminDetailData: objAdminDetailData)
                }
                if kStorage.isChatLive, Utility.isLiveChatScreenOnTop() {
                    CustomDelegates.liveChatDelegate?.checkLatestMsg()
                }
            }
        case kSocketEvents.SendMessage:
            let objMessageDataLiveChat = dataModel as! MessageDataLiveChat
            CustomDelegates.liveChatDelegate?.messageSent(data: objMessageDataLiveChat)
        case kSocketEvents.ReceiveMessage:
            let objMessageDataLiveChat = dataModel as! MessageDataLiveChat
            CustomDelegates.liveChatDelegate?.messageReceived(data: objMessageDataLiveChat)
        case kSocketEvents.ReadMessage:
            let objReadMessageData = dataModel as! ReadMessageData
            CustomDelegates.liveChatDelegate?.messageRead(data: objReadMessageData.readMsg)
        case kSocketEvents.GetConversion:
            let objChatHistoryData = dataModel as! ChatHistoryData
            Utility.countTotalPage(totalRecords: pager.totalRecords)
            CustomDelegates.liveChatDelegate?.getConversion(chatBasePath: objChatHistoryData.chatBasePath, data: objChatHistoryData.chatHistory, isPaging: pager.pageNumber != 1)
        case kSocketEvents.GetLatestMsg:
            let objChatHistoryData = dataModel as! ChatHistoryData
            CustomDelegates.liveChatDelegate?.getLatestMsg(data: objChatHistoryData.chatHistory)
        default:
            print("Invalid Event Received!!!")
        }
    }
    
}
