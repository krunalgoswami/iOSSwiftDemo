import UIKit

protocol CountrySelectionDelegate {
    func countrySelected(country:Country)
    func StripeCountrySelected(country:StripeCountry)
}

protocol MediaSelectionDelegate {
    func mediaSelected(media:TopicOrArtCategory)
}

protocol ProfessionOrPreferencesDelegate {
    func itemsSelected(isProfession:Bool, selectedArrayProfessionOrPreferences:[Professions])
}

protocol ArtDelegate {
    func artDeleted()
}

protocol ArtTagsSelectionDelegate {
    func artTagsSeleted(artTags:[TopicOrArtCategory])
}

protocol RewardDelegate {
    func applyReferCode(rewardAmount:Double)
}

protocol UpdateUserDelegate {
    func userProfileUpdated()
}

protocol PaymentCardDelegate {
    func cardSelected(selectedCardInfo:CardsInfo)
    func newCardAdded()
}

extension PaymentCardDelegate{
    func cardSelected(selectedCardInfo:CardsInfo){}
    func newCardAdded(){}
}

protocol UserMobileNumberUpdateDelegate{
    func mobileNumberUpdated()
}

protocol OrderDelegate{
    func newOrderedAdded()
}

protocol SearchProductDelegate{
    func refreshPopularSearchDataIfNeeded()
}

protocol RootTabbarDelegate{
    func reasignLoginSignUpPopUpDelegate()
}

protocol ReviewRatingDelegate{
    func submitedReviewRating()
}

protocol LoginSignUpPopUpDelegate{
    func loginWithTektonClicked()
    func signUpWithFacebookOrSignUpWithTektonClicked()
    func signUpWithInstagramClicked()
    func signUpWithYoutubeClicked()
    func dismissViewOnFacebookSignIn()
}

extension LoginSignUpPopUpDelegate{
    func loginWithTektonClicked(){}
    func signUpWithFacebookOrSignUpWithTektonClicked(){}
    func signUpWithInstagramClicked(){}
    func signUpWithYoutubeClicked(){}
    func dismissViewOnFacebookSignIn(){}
}

protocol LiveChatDelegate{
    func readyForLiveChat(adminDetailData:AdminDetailData?)
    func checkLatestMsg()
    func networkIssueResolved()
    func closeLiveChat()
    func backFromDeepLinking()
    func getConversion(chatBasePath:String, data:[MessageLiveChat]?, isPaging:Bool)
    func getLatestMsg(data:[MessageLiveChat]?)
    func messageSent(data:MessageDataLiveChat?)
    func messageReceived(data:MessageDataLiveChat?)
    func messageRead(data:[MessageLiveChat]?)
}

extension CountrySelectionDelegate{
    func countrySelected(country:Country){}
    func StripeCountrySelected(country:StripeCountry){}
}

protocol NotificationDelegate {
    func getNotifications()
}
protocol ChangeTabBarTabDelegate {
    func changeTabBarTab(tabBarIndex:Int?)
}


