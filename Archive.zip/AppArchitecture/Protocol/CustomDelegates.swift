import UIKit

struct CustomDelegates {
    static var countrySelectionDelegate:CountrySelectionDelegate?
    static var professionOrPreferencesDelegate:ProfessionOrPreferencesDelegate?
    static var artDelegate:ArtDelegate?
    static var artTagsSelectionDelegate:ArtTagsSelectionDelegate?
    static var rewardDelegate:RewardDelegate?
    static var updateUserDelegate:UpdateUserDelegate?
    static var mediaSelectionDelegate:MediaSelectionDelegate?
    static var paymentCardDelegate:PaymentCardDelegate?
    static var userMobileNumberUpdateDelegate:UserMobileNumberUpdateDelegate?
    static var orderDelegate:OrderDelegate?
    static var loginSignUpPopUpDelegate:LoginSignUpPopUpDelegate?
    static var liveChatDelegate:LiveChatDelegate?
    static var searchProductDelegate:SearchProductDelegate?
    static var rootTabbarDelegate:RootTabbarDelegate?
    static var reviewRatingDelegate:ReviewRatingDelegate?
    static var notificationDelegate:NotificationDelegate?
    static var changeTabBarTabDelegate:ChangeTabBarTabDelegate?
}

