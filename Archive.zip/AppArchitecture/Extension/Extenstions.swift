import UIKit

public func ==(lhs: [String: Any], rhs: [String: Any] ) -> Bool {
    return NSDictionary(dictionary: lhs).isEqual(to: rhs)
}

func += <K, V> (left: inout [K:V], right: [K:V]) {
    for (k, v) in right {
        left[k] = v
    }
}

class PickerTextField : UITextField{
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        if action == #selector(UIResponderStandardEditActions.paste(_:)) {
            return false
        }
        return super.canPerformAction(action, withSender: sender)
    }
}

extension UITextField{
    @IBInspectable var placeHolderColor: UIColor? {
        get {
            return self.placeHolderColor
        }
        set {
            self.attributedPlaceholder = NSAttributedString(string:self.placeholder != nil ? self.placeholder! : "", attributes:[NSForegroundColorAttributeName: newValue!])
        }
    }
}

extension UITableView {
    func reloadData(completion: @escaping ()->()) {
        UIView.animate(withDuration: 0, animations: { self.reloadData() })
        { _ in completion() }
    }
}

extension UIView {
    func addGradientLayer(viewHeight:CGFloat, gradientHeight:CGFloat) {
        let bottomViewGradient = CAGradientLayer()
        bottomViewGradient.startPoint = CGPoint(x: 1.0, y: 0.0)
        bottomViewGradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        let topColor = UIColor.WhiteFullTransparent
        let bottomColor = UIColor.white
        bottomViewGradient.colors = [topColor.cgColor, bottomColor.cgColor]
        bottomViewGradient.locations = [0, 1]
        self.layoutIfNeeded()
        bottomViewGradient.frame = CGRect(x: 0, y: viewHeight - gradientHeight, width: self.bounds.width, height: gradientHeight)
        self.layer.insertSublayer(bottomViewGradient, at: 0)
    }
    
    func setBottomBorder(borderColor:UIColor = UIColor.TextFieldBottomSeprator) {
        self.layer.backgroundColor = UIColor.white.cgColor
        self.layer.masksToBounds = false
        self.layer.shadowColor = borderColor.cgColor
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        self.layer.shadowOpacity = 1.0
        self.layer.shadowRadius = 0.0
    }
}

extension String{
    func getAtttibuteString(target:String, font:UIFont, boldFont:UIFont = UIFont(name: kFonts.AvenirMedium, size: 18.0)!, boldColor:UIColor = UIColor.black) -> NSMutableAttributedString {
        let attributedLabelString = NSMutableAttributedString(string: self, attributes: [NSFontAttributeName : font])
        let attributesDict = [NSFontAttributeName:boldFont, NSForegroundColorAttributeName:boldColor]
        attributedLabelString.setAttributes(attributesDict, range: (self as NSString).range(of: target))
        return attributedLabelString
    }
    
    func grouping(every groupSize: String.IndexDistance, with separator: Character) -> String {
        let cleanedUpCopy = replacingOccurrences(of: String(separator), with: "")
        return String(cleanedUpCopy.characters.enumerated().map() {
            $0.offset % groupSize == 0 ? [separator, $0.element] : [$0.element]
            }.joined().dropFirst())
    }
    
    func removingWhitespaces() -> String {
        return components(separatedBy: .whitespaces).joined()
    }

    func stringByRemovingEmoji() -> String {
        return String(self.characters.filter { !$0.isEmoji() })
    }

}

extension Character {
    fileprivate func isEmoji() -> Bool {
        switch self {
        case Character(UnicodeScalar(UInt32(0x1d000))!)...Character(UnicodeScalar(UInt32(0x1f77f))!), //General Emoticons
        Character(UnicodeScalar(UInt32(0x2100))!)...Character(UnicodeScalar(UInt32(0x26ff))!), //General Emoticons
        Character(UnicodeScalar(UInt32(0x1F600))!)...Character(UnicodeScalar(UInt32(0x1F64F))!), // Emoticons
        Character(UnicodeScalar(UInt32(0x1F300))!)...Character(UnicodeScalar(UInt32(0x1F5FF))!), // Misc Symbols and Pictographs
        Character(UnicodeScalar(UInt32(0x1F680))!)...Character(UnicodeScalar(UInt32(0x1F6FF))!), // Transport and Map
        Character(UnicodeScalar(UInt32(0x2600))!)...Character(UnicodeScalar(UInt32(0x26FF))!), // Misc symbols
        Character(UnicodeScalar(UInt32(0x2700))!)...Character(UnicodeScalar(UInt32(0x27BF))!), // Dingbats
        Character(UnicodeScalar(UInt32(0xFE00))!)...Character(UnicodeScalar(UInt32(0xFE0F))!), // Variation Selectors
        Character(UnicodeScalar(UInt32(0x1F900))!)...Character(UnicodeScalar(UInt32(0x1F9FF))!), //Supplemental Symbols and Pictographs
        Character(UnicodeScalar(UInt32(65024))!)...Character(UnicodeScalar(UInt32(65039))!), // Variation selector
        Character(UnicodeScalar(UInt32(8400))!)...Character(UnicodeScalar(UInt32(8447))!): //Combining Diacritical Marks for Symbols
            return true
        default:
            return false
        }
    }
}


extension SearchResultCell {
    func setCollectionViewDataSourceDelegate<D: UICollectionViewDataSource & UICollectionViewDelegate>(_ dataSourceDelegate: D, forRow row: Int) {
        searchProductCollectionView.delegate = dataSourceDelegate
        searchProductCollectionView.dataSource = dataSourceDelegate
        searchProductCollectionView.tag = row
        searchProductCollectionView.setContentOffset(searchProductCollectionView.contentOffset, animated:false) // Stops collection view if it was scrolling.
        searchProductCollectionView.reloadData()
    }
    
    var collectionViewOffset: CGFloat {
        set { searchProductCollectionView.contentOffset.x = newValue }
        get { return searchProductCollectionView.contentOffset.x }
    }
}


extension PopularSearchCell {
    func setTableViewViewDataSourceDelegate<D: UITableViewDataSource & UITableViewDelegate>(_ dataSourceDelegate: D, forRow row: Int) {
        popularSearchProductTableView.delegate = dataSourceDelegate
        popularSearchProductTableView.dataSource = dataSourceDelegate
        popularSearchProductTableView.tag = row
        popularSearchProductTableView.reloadData()
    }
}
extension PayoutPaymentCell {
    func setTableViewViewDataSourceDelegate<D: UITableViewDataSource & UITableViewDelegate>(_ dataSourceDelegate: D, forRow row: Int) {
        parentTableView.delegate = dataSourceDelegate
        parentTableView.dataSource = dataSourceDelegate
        parentTableView.tag = row
        parentTableView.reloadData()
    }
}

extension UIApplication {
    class func topViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return topViewController(base: nav.visibleViewController)
        }
        if let tab = base as? UITabBarController {
            if let selected = tab.selectedViewController {
                return topViewController(base: selected)
            }
        }
        if let presented = base?.presentedViewController {
            return topViewController(base: presented)
        }
        return base
    }
}

extension UIImage{
    static func fromColor(color: UIColor, height:CGFloat = 1, width:CGFloat = 1, isRound:Bool = false) -> UIImage {
        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()
        context!.setFillColor(color.cgColor)
        isRound ? context!.fillEllipse(in: rect) : context!.fill(rect)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img!
    }
    
    func fixedOrientation() -> UIImage {
        // No-op if the orientation is already correct
        if (imageOrientation == UIImageOrientation.up) {
            return self
        }
        
        // We need to calculate the proper transformation to make the image upright.
        // We do it in 2 steps: Rotate if Left/Right/Down, and then flip if Mirrored.
        var transform:CGAffineTransform = CGAffineTransform.identity
        
        if (imageOrientation == UIImageOrientation.down
            || imageOrientation == UIImageOrientation.downMirrored) {
            
            transform = transform.translatedBy(x: size.width, y: size.height)
            //            transform = transform.rotated(by: CGFloat(M_PI))
            transform = transform.rotated(by: CGFloat(Double.pi))
        }
        
        if (imageOrientation == UIImageOrientation.left
            || imageOrientation == UIImageOrientation.leftMirrored) {
            
            transform = transform.translatedBy(x: size.width, y: 0)
            //            transform = transform.rotated(by: CGFloat(M_PI_2))
            transform = transform.rotated(by: CGFloat(Double.pi/2))
        }
        
        if (imageOrientation == UIImageOrientation.right
            || imageOrientation == UIImageOrientation.rightMirrored) {
            
            transform = transform.translatedBy(x: 0, y: size.height);
            //            transform = transform.rotated(by: CGFloat(-M_PI_2));
            transform = transform.rotated(by: CGFloat(-Double.pi/2));
        }
        
        if (imageOrientation == UIImageOrientation.upMirrored
            || imageOrientation == UIImageOrientation.downMirrored) {
            
            transform = transform.translatedBy(x: size.width, y: 0)
            transform = transform.scaledBy(x: -1, y: 1)
        }
        
        if (imageOrientation == UIImageOrientation.leftMirrored
            || imageOrientation == UIImageOrientation.rightMirrored) {
            
            transform = transform.translatedBy(x: size.height, y: 0);
            transform = transform.scaledBy(x: -1, y: 1);
        }
        
        // Now we draw the underlying CGImage into a new context, applying the transform
        // calculated above.
        let ctx:CGContext = CGContext(data: nil, width: Int(size.width), height: Int(size.height),
                                      bitsPerComponent: cgImage!.bitsPerComponent, bytesPerRow: 0,
                                      space: cgImage!.colorSpace!,
                                      bitmapInfo: cgImage!.bitmapInfo.rawValue)!
        
        ctx.concatenate(transform)
        
        if (imageOrientation == UIImageOrientation.left
            || imageOrientation == UIImageOrientation.leftMirrored
            || imageOrientation == UIImageOrientation.right
            || imageOrientation == UIImageOrientation.rightMirrored
            ) {
            ctx.draw(cgImage!, in: CGRect(x:0,y:0,width:size.height,height:size.width))
        } else {
            ctx.draw(cgImage!, in: CGRect(x:0,y:0,width:size.width,height:size.height))
        }
        
        // And now we just create a new UIImage from the drawing context
        let cgimg:CGImage = ctx.makeImage()!
        let imgEnd:UIImage = UIImage(cgImage: cgimg)
        
        return imgEnd
    }
}

extension UIColor {
    
    class var SaveButtonTitle: UIColor {
        return UIColor(red: 64/255, green: 202/255, blue: 247/255, alpha: 1.0)
    }
    
    class var ProgressHud: UIColor {
        return UIColor(red:0.09, green:0.02, blue:0.02, alpha:1.0)
    }
    
    class var WhiteFullTransparent: UIColor {
        return UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 0.0)
    }
    
    class var DisableGray: UIColor {
        return UIColor(red: 214/255, green: 214/255, blue: 214/255, alpha: 1.0)
    }
    
    class var GrayPanel: UIColor {
        return UIColor(red: 243/255, green: 243/255, blue: 243/255, alpha: 1.0)
    }
    
    class var BlueTextField: UIColor {
        return UIColor(red: 29/255, green: 86/255, blue: 140/255, alpha: 1.0)

    }
    
    class var BlueText: UIColor {
        return UIColor(red: 0/255, green: 117/255, blue: 246/255, alpha: 1.0)
    }
    
    class var LigthGrayBorder: UIColor {
        return UIColor(red: 183/255, green: 183/255, blue: 183/255, alpha: 1.0)
    }
    
    class var LigthGrayVerifyID: UIColor {
        return UIColor(red: 122/255, green: 133/255, blue: 145/255, alpha: 1.0)
    }
    
    class var LigthGrayTransparentBorder: UIColor {
        return UIColor(red: 183/255, green: 183/255, blue: 183/255, alpha: 0.45)
    }
    
    class var ArtisProfile: UIColor {
        return UIColor(red: 80/255, green: 47/255, blue: 255/255, alpha: 1.0)
    }
    
    class var Theme: UIColor {
        return UIColor(red: 136/255, green: 176/255, blue: 75/255, alpha: 1.0)
    }
    
    class var ThemeTransparent: UIColor {
        return UIColor(red: 136/255, green: 176/255, blue: 75/255, alpha: 0.45)
    }
    
    class var ThemeTransparentLight: UIColor {
        return UIColor(red: 136/255, green: 176/255, blue: 75/255, alpha: 0.25)
    }

    class var WhiteDisableJoin: UIColor {
        return UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 0.6)
    }
    
    class var LightGreen: UIColor {
        return UIColor(red: 129/255, green: 168/255, blue: 88/255, alpha: 0.72)
    }
    
    class var DarkGreen: UIColor {
        return UIColor(red: 82/255, green: 140/255, blue: 86/255, alpha: 1.0)
    }
    
    class var GreenReferCode: UIColor {
        return UIColor(red: 83/255, green: 135/255, blue: 62/255, alpha: 1.0)
    }
    
    class var GreenSearchPlaceholder: UIColor {
        return UIColor(red: 164/255, green: 194/255, blue: 117/255, alpha: 1.0)
    }
    
    class var BlackNavigationBar: UIColor {
        return UIColor(red:32/255, green:29/255, blue:33/220, alpha:1.0)
    }
    
    class var SelectedTab: UIColor {
        return UIColor(red:93/255, green:187/255, blue:74/220, alpha:1.0)
    }
    
    class var TabbarBackground: UIColor {
        return UIColor(red:243/255, green:243/255, blue:243/220, alpha:1.0)
    }
    
    class var ArtistTheme: UIColor {
        return UIColor(red: 80/255, green: 47/255, blue: 255/255, alpha: 1.0)
    }

    class var ArtistThemeLight: UIColor {
        return UIColor(red: 80/255, green: 47/255, blue: 255/255, alpha: 0.40)
    }

    class var PurplePayoutForm: UIColor {
        return UIColor(red: 125/255, green: 101/255, blue: 230/255, alpha: 1.0)
    }
    
    class var TextFieldBottomSeprator: UIColor {
        return UIColor(red:0/255, green:0/255, blue:0/220, alpha:1.0)
    }
    
    class var ResendCodeBorder: UIColor {
        return UIColor(red:0/255, green:0/255, blue:0/220, alpha:0.5)
    }
    
    class var TealSelected: UIColor {
        return UIColor(red: 48/255, green: 250/255, blue: 246/255, alpha: 1)
    }
    
    class var DarkYellowSelected: UIColor {
        return UIColor(red: 207/255, green: 222/255, blue: 57/255, alpha: 1)
    }
    
    class var LightYellowSelected: UIColor {
        return UIColor(red: 220/255, green: 228/255, blue: 130/255, alpha: 1)
    }
    
    class var LightPurpleSelected: UIColor {
        return UIColor(red: 79/255, green: 97/255, blue: 189/255, alpha: 1)
    }
    
    class var PurpleUploadArtBack: UIColor {
        return UIColor(red: 50/255, green: 50/255, blue: 87/255, alpha: 1)
    }
    
    class var PurpleDisable: UIColor {
        return UIColor(red: 80/255, green: 47/255, blue: 225/255, alpha: 0.5)
    }
    
    class var PurpleEnable: UIColor {
        return UIColor(red: 80/255, green: 47/255, blue: 225/255, alpha: 1)
    }
    
    class var NeonGreenSelected: UIColor {
        return UIColor(red: 78/255, green: 221/255, blue: 80/255, alpha: 1)
    }
    
    class var NudeSelected: UIColor {
        return UIColor(red: 222/255, green: 194/255, blue: 112/255, alpha: 1)
    }
    
    class var UserProfileRightArrow: UIColor {
        return UIColor(red:247/255, green:213/255, blue:139/220, alpha:1.0)
    }
    
    class var NotificationRightArrow: UIColor {
        return UIColor(red:79/255, green:147/255, blue:249/220, alpha:1.0)
    }
    
    class var PayoutMethodRightArrow: UIColor {
        return UIColor(red:137/255, green:177/255, blue:76/220, alpha:1.0)
    }
    
    class var CurrencyRightArrow: UIColor {
        return UIColor(red:225/255, green:179/255, blue:19/220, alpha:1.0)
    }
    
    class var TermsOfServiceRightArrow: UIColor {
        return UIColor(red:249/255, green:120/255, blue:120/220, alpha:1.0)
    }
    
    class var InboxNavBarTheme: UIColor {
        return UIColor(red:133/255, green:49/255, blue:247/220, alpha:1.0)
    }
    
    class var BlackTag: UIColor {
        return UIColor(red: 66/255, green: 134/255, blue: 244/255, alpha: 0.79)
    }
    
    class var ArtisTermsUse: UIColor {
        return UIColor(red: 133/255, green: 49/255, blue: 247/255, alpha: 1.0)
    }
    
}
