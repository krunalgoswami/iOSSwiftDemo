import UIKit

struct kData{

    static let PayoutMethodArray : [NSDictionary] = [
        ["_id":"1", "name":"Stripe Instant Payout"],
    ]
    
    static let CurrencyArray : [NSDictionary] = [
        ["_id":"1", "name":"USD"],
    ]

    static let PayoutMediumArray : [NSDictionary] = [
        ["_id":"1", "name":"Debit Card"],["_id":"2", "name":"Bank Account"]
        ]
    
    static let MemberArtistArray : [NSDictionary] = [
        ["_id":"0", "name":"Member","image":"imgMember"],["_id":"1", "name":"Artist","image":"imgArtist.pdf"],["_id":"2", "name":"Enterprise (Coming 2018)","image":"imgEnterprise.pdf"]
    ]

    static let StripDetailArray : [NSDictionary] = [["_id":"1", "country":"AU", "isRoutingNumber":true, "isAccountNumber":true, "isIBAN":false, "titleAccountNumber":"Account Number", "titleRoutingNumber":"BSB", "titleIBAN":"","currency":"aud"],["_id":"2", "country":"AT", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"3", "country":"BE", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"4", "country":"BR", "isRoutingNumber":true, "isAccountNumber":true, "isIBAN":true, "titleAccountNumber":"Account Number", "titleRoutingNumber":"Bank Code", "titleIBAN":"Branch Code","currency":"brl"],["_id":"5", "country":"CA", "isRoutingNumber":true, "isAccountNumber":true, "isIBAN":true, "titleAccountNumber":"Account Number", "titleRoutingNumber":"Transit Number", "titleIBAN":"Institution Number","currency":"usd"],["_id":"6", "country":"DK", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"7", "country":"FI", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"8", "country":"FR", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"9", "country":"DE", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"10", "country":"HK", "isRoutingNumber":true, "isAccountNumber":true, "isIBAN":true, "titleAccountNumber":"Account Number", "titleRoutingNumber":"Clearing Code", "titleIBAN":"Branch Code","currency":"hkd"],["_id":"11", "country":"IE", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"12", "country":"IT", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"13", "country":"JP", "isRoutingNumber":true, "isAccountNumber":true, "isIBAN":true, "titleAccountNumber":"Account Number", "titleRoutingNumber":"Branch Code", "titleIBAN":"Bank Code","currency":"jpy"],["_id":"14", "country":"LU", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"15", "country":"MX", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"CLABE","currency":"mxn"],["_id":"16", "country":"NL", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"17", "country":"NZ", "isRoutingNumber":true, "isAccountNumber":true, "isIBAN":false, "titleAccountNumber":"Account Number", "titleRoutingNumber":"Branch Code", "titleIBAN":"","currency":"nzd"],["_id":"18", "country":"NO", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"nok"],["_id":"19", "country":"PT", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"20", "country":"SG", "isRoutingNumber":true, "isAccountNumber":true, "isIBAN":true, "titleAccountNumber":"Account Number", "titleRoutingNumber":"Bank Code", "titleIBAN":"Branch Code","currency":"sgd"],["_id":"21", "country":"ES", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"eur"],["_id":"22", "country":"SE", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"sek"],["_id":"23", "country":"CH", "isRoutingNumber":false, "isAccountNumber":false, "isIBAN":true, "titleAccountNumber":"", "titleRoutingNumber":"", "titleIBAN":"IBAN","currency":"chf"],["_id":"24", "country":"GB", "isRoutingNumber":true, "isAccountNumber":true, "isIBAN":false, "titleAccountNumber":"Account Number", "titleRoutingNumber":"Sort Code", "titleIBAN":"","currency":"gbp"],["_id":"25", "country":"US", "isRoutingNumber":true, "isAccountNumber":true, "isIBAN":false, "titleAccountNumber":"Account Number", "titleRoutingNumber":"Routing Number", "titleIBAN":"","currency":"usd"]]
    
    static var PaymentMethodArray : [NSDictionary] = [
        ["title":"Payment methods","data":[
            ["paymentTitle":"Coinbase Wallet", "detail":"", "brand":"imgCoinBase.pdf","_id":"3","cardId":"","country":"","month":"","year":"","isCardDetail":false,"last4":0,"isEnable":true],
            ["paymentTitle":"Add Credit Card", "detail":"", "brand":"imgAddCard.pdf","_id":"4","country":"","month":"","year":"","isCardDetail":false,"last4":0,"isEnable":true],
            ["paymentTitle":"Tekton Credits", "detail":"75", "brand":"","_id":"5","country":"","month":"","year":"","isCardDetail":false,"last4":0,"isEnable":true],
            ]]
    ]
    
    static var PaymentPayoutMethodArray : [NSDictionary] = [
        ["title":"Payout Cards","data":[
            ["paymentTitle":"Add Debit Card", "detail":"", "brand":"imgAddCard.pdf","_id":"4","country":"","month":"","year":"","isCardDetail":false,"cardNumber":0,"isEnable":true],
            ]],
        ["title":"Payout Banks","data":[
            ["paymentTitle":"Add Bank", "detail":"", "brand":"imgAddBank.pdf","_id":"5","country":"","month":"","year":"","isCardDetail":false,"cardNumber":0,"isEnable":true],
            ]]
    ]
    
    static let UploadArtMenuArray : [NSDictionary] = [
        ["name":"Take a Picture", "detail":" ", "image":"imgCamera"],
        ["name":"Photo Library", "detail":" ", "image":"imgPhotoLibrary"],
        ["name":"Cloud Drives", "detail":"iCloud, Dropbox, Drive, etc", "image":"imgCloudDrives"],
        ["name":"Adobe Creative Cloud", "detail":"Connect and use your Adobe account", "image":"imgAdobeCreativeCloud.png"]
    ]
    
    static let TeeSizeArray : [String] = ["S","M","L","XL","2XL"]
    
    static let SupportArray : [NSDictionary] = [
        ["title" : "Modify your order"],
        ["title" : "Technical Assistance"],
        ["title" : "Partnership Inquires"],
        ["title" : "FAQ’s"]
    ]
    
    static let arraySettingMenuArtist : [NSDictionary] =  [
        ["name" : "Pablo Picasso","image" : "profile.pdf","color":UIColor.UserProfileRightArrow],
        ["name" : "Notifications","image" : "notification.pdf","color":UIColor.NotificationRightArrow],
        ["name" : "Payout Method","image" : "payoutMethod.pdf","color":UIColor.PayoutMethodRightArrow],
        ["name" : "Currency","image" : "currency.pdf","color":UIColor.CurrencyRightArrow],
        ["name" : "Terms of Service","image" : "termsService.pdf","color":UIColor.TermsOfServiceRightArrow]
    ]
    
    static let arraySettingMenuBuyer : [NSDictionary] =  [
        ["name" : "Pablo Picasso","image" : "profile.pdf","color":UIColor.Theme],
        ["name" : "pp@picasso.org","image" : "imgBuyerEmail.pdf","color":UIColor.Theme],
        ["name" : "854-888-8889","image" : "imgBuyerMobile.pdf","color":UIColor.Theme],
        ["name" : "Notifications","image" : "imgBuyerNotification.pdf","color":UIColor.Theme],
        ["name" : "Member / Artist","image" : "imgBuyerUser.pdf","color":UIColor.Theme]
    ]
    
    static let HomeMenuArray : [NSDictionary] = [
        ["name":"Releases", "image":"imgReleases"],
        ["name":"Charts", "image":"imgCharts"],
        ["name":"Artists", "image":"imgArtists"],
        ["name":"Videos", "image":"imgVideos"]
    ]
    
    static let ProfileMenuBuyer : [NSDictionary] = [
        ["name" : "Inbox"],
        ["name" : "Support"],
        ["name" : "Tracking"],
        ["name" : "Perks"],
        ["name" : "Payment"],
        ["name" : "Reviews"],
        ["name" : "Settings"],
        ["name" : "Switch to Artist"]
    ]
    
    static let ProfileMenuArtist : [NSDictionary] = [
        ["name" : "Inbox"],
        ["name" : "Sales"],
        ["name" : "Gallery"],
        ["name" : "Refer Artists"],
        ["name" : "Reviews"],
        ["name" : "Settings"],
        ["name" : "Switch to Buyer"]
    ]
    
}
