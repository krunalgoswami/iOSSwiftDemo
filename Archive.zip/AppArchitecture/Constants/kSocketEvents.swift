struct kSocketEvents {
    static let JoinRoom = "joinRoom"
    static let SendMessage = "sendMessage"
    static let ReceiveMessage = "receiveMessage"
    static let ReadMessage = "readMessage"
    static let GetConversion = "getConversion"
    static let GetLatestMsg = "getLatestMsg"
}
