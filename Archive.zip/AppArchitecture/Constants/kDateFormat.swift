//
//  kDateFormat.swift
//  Tekton
//
//  Created by smartSense on 23/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

struct kDateFormat {

}
