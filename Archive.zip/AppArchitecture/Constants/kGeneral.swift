struct kGeneral {
    static let StoryMain = UIStoryboard(name: "Main", bundle: nil)
    static let NavController = UINavigationController(nibName: kViewController.RootNavController, bundle: nil)

    static let ScreenSize = UIScreen.main.bounds.size
    static let KeyboardHeight:CGFloat = kGeneral.ScreenSize.width <= 375 ? 216 : 226
    static let is5sOrLess:Bool = kGeneral.ScreenSize.width <= 320
    static let is6s:Bool = kGeneral.ScreenSize.width == 375
    static let ToastYOffset:CGFloat = kGeneral.ScreenSize.height/2 * 0.7
    static let ToastYOffsetMiddle:CGFloat = (kGeneral.ScreenSize.height / 10) * 0.1
    static let DoneToolBarHeight:CGFloat = 50

    static let ImageLimitUserProfile:Double = 5
    static let ImageLimitUploadArt:Double = 28
    static let ImageLimitChat:Double = 10
    
    static let networkManager = NetworkManager.sharedInstance()
    static let appDelegate = UIApplication.shared.delegate as! AppDelegate
    static let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    static let loginSignUpPopup = LoginSignUpPopup()
}
