struct kFonts {
    static let AvenirMedium = "Avenir-Medium"
    static let AvenirHeavyOblique = "Avenir-HeavyOblique"
    static let AvenirBook = "Avenir-Book"
    static let AvenirLight = "Avenir-Light"
    static let AvenirRoman = "Avenir-Roman"
    static let AvenirBookOblique = "Avenir-BookOblique"
    static let AvenirMediumOblique = "Avenir-MediumOblique"
    static let AvenirBlack = "Avenir-Black"
    static let AvenirBlackOblique = "Avenir-BlackOblique"
    static let AvenirHeavy = "Avenir-Heavy"
    static let AvenirLightOblique = "Avenir-LightOblique"
    static let AvenirOblique = "Avenir-Oblique"
}
