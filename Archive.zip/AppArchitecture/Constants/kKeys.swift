struct kKeys {
    static let searchField = "searchField"
    static let userAuthToken = "userAuthToken"
    static let user = "user"
    static let userImagePath = "userImagePath"
    static let socialFollowers = "socialFollowers"
    static let referAmount = "referAmount"



    static let coverImage = "coverImage"
    static let coverAnimatedImage = "coverAnimatedImage"

    static let signUpPersonalImage = "signUpPersonalImage"
    static let signUpSelectionImage = "signUpSelectionImage"
    static let signUpProfessionOrPreferenceslImage = "signUpProfessionOrPreferenceslImage"
    static let payoutMethod = "payoutMethod"
    static let currency = "currency"
    static let isAppAlreadyLaunched = "isAppAlreadyLaunched"
    static let splashView = "SplashView"

    
    
    struct UserProfile {
        static let name = "name"
        static let image = "image"
        static let email = "email"
        static let gender = "gender"
        static let birthDate = "birthDate"
        static let teeSize = "teeSize"
        static let about = "about"
    }
}
