struct kToast {
    struct HudTitle {
        static let ResolvingNetwork = "Resolving Network\nIssue..."
        static let PleaseWait = "Please Wait..."
    }

    struct Validation {
        static let EmptyName = "The name field is required."
        static let EmptyBirdthday = "The birthday field is required."
        static let EmptyEmail = "The email field is required."
        static let EmptyMobile = "The mobile field is required."
        static let EmptyCountryCode = "The country code is required."
        static let EmptyOtp = "Enter valid OTP."
        static let EmptyCardNumber = "The card number field is required."
        static let EmptyExpireYear = "The expire year field is required."
        static let EmptyExpireMonth = "The expire month field is required."
        static let EmptyCvv = "The CVV number field is required."

        static let EmptyArtCaption = "The art caption field is required."
        static let EmptyImageTitle = "The image title field is required."
        static let EmptyCreationDate = "The creation date field is required."
        static let EmptyMedium = "The medium field is required."
        static let EmptySize = "The size field is required."
        static let EmptyWidth = "The width field is required."
        static let EmptyHeight = "The height field is required."

        static let EmptyValue = "The value field is required."
        static let EmptyReferCode = "The refer code field is required."
        static let EmptyComment = "The comment should not empty."

        static let EmptyFistName = "The Fistname field should not empty."
        static let EmptyLastName = "The Lastname field should not empty."
        static let EmptyBirthDate = "The Birthdate field should not empty."
        static let EmptyState = "The State field should not empty."
        static let EmptyCity = "The City field should not empty."
        static let EmptyPostal = "The Postal field should not empty."
        static let EmptySSN = "The SSN field should not empty."
        static let EmptyPersonalID = "The PersonalID field should not empty."
        static let EmptyIDImage = "The IDImage field should not empty."
        static let EmptyAddress = "The Address field should not empty."

        static let Name = "The name length must be between 3 and 100."
        static let Email = "The email must be a valid email."
        static let EmailRange = "The email length must be between 3 and 100."
        static let Mobile = "The mobile length must be between 4 and 15."
        static let PNGorJPG = "The image must be of type .jpg, .jpeg or .png"
        static let AdobeFileSupport = "The file must be type of  .ai or .psd"
        static let ImageSize = "The image may not be greater than"
        static let About = "The about length must be between 5 and 500."
        static let NoArtTags = "Select At least One Art Tag"
        static let Otp = "The OTP length must be exact 6 characters."

        static let OverallExp = "The overall experience rating is required."
        static let ArtPrintQua = "The art Print Quality rating is required."
        static let Fit =  "The fit rating is required."
        static let Turnaround = "The turnaround rating is required."
        static let ProductSize = "Please select valid product size."
        static let ArtSizeWidth = "The width field must be valid."
        static let ArtSizeHeight = "The height field must be valid."

        static let ProductQuantity = "Please select valid product quantity."
        static let CreditCardNumber = "The card number length must be 16 digit."
        static let Cvv = "The CVV number must be valid."
        static let ExpireYear = "The expire year field is must be valid."
        static let ExpireMonth = "The expire month field is must be valid."
        static let CardNotValid = "Invalid card details."
        static let Value = "The Value field must be valid."
        static let ReviewDescription = "The description length may not be grater then 500."
        static let ArtDescription = "The description length must be between 2 and 500."
        static let ArtTitleName = "The image title length must be between 3 and 100."
        static let SelectStripeCountry = "The Country  must be selected."
        static let FileNotSupport = "This file not supported"
        static let WalletBalance = "You at least need $\(String(format: "%.2f", max(20.0, kStorage.objUser.payoutDefaultLimit))) to process your checkout."
    }
    
    struct Success {
        static let OtpVerified = "OTP verified sucessfully."
        static let OtpResent = "OTP resent sucessfully."
        static let ReviewSend = "Reviews sent sucessfully."
        static let ProfileUpdated = "Your Profile Updated sucessfully."
        static let CreditCardAdded = "Your credit card has been added sucessfully."
        static let ArtDeleted = "Art deleted sucessfully."
        static let SignUp = "Congrats! You have successfully registered."
        static let Login = "Congrats! You have successfully login."
    }
    
    struct General {
        static let CheckInternetConnection = "Please check your internet connection."
        static let SocketConnection = "Server connection lost. Please try after sometime."
        static let NetworkConnection = "Network connection error. Please try after sometime."
        static let NotSupportCamera = "Your device not support camera"
        static let RequestTimedOut = "The request timed out."
        static let AppUnderMaintainance = "App is under maintainance.Please try after sometime."
        static let SomethingWentWrong = "Something went wrong."
        static let CopyText = "Copied text."
        static let PhotoRestricted = "This application is not authorized to access photo data."
        static let CameraRestricted = "This application is not authorized to access Camera."
    }
}
