struct kCell{
    
    // MARK:- Tableview Cell
    struct Table {
        static let ProfileCell = "ProfileCell"
        static let VideoCell = "VideoCell"
        static let CountryCell = "CountryCell"
        static let MenuCell = "MenuCell"
        static let SettingMenuCell = "SettingMenuCell"
        static let ArtistListCell = "ArtistListCell"
        static let ChartListCell = "ChartListCell"
        static let SupportCell = "SupportCell"
        static let OrderStatusDetailCell = "OrderStatusDetailCell"
        static let ThankYouCell = "ThankYouCell"
        static let SalesSummaryCell = "SalesSummaryCell"
        static let InboxCell = "InboxCell"
        static let ArtistReviewCell = "ArtistReviewCell"
        static let UploadArtCell = "UploadArtCell"
        static let PaymentMethodCell = "PaymentMethodCell"
        static let SelectArtTagCell = "SelectArtTagCell"
        static let SearchArtCell = "SearchArtCell"
        static let LiveChatCell = "LiveChatCell"
        static let SelectArtCategoryCell = "SelectArtCategoryCell"
        static let SearchResultCell = "SearchResultCell"
        static let PopularSearchCell = "PopularSearchCell"
        static let MemberArtistCell = "MemberArtistCell"
        static let RadioCell = "RadioCell"
        static let NotificationCell = "NotificationCell"
        static let PayoutPaymentCell = "PayoutPaymentCell"
    }
    
    // MARK:- Collectionview Cell
    struct Collection {
        static let SignUpProfessionOrPreferencesCell = "SignUpProfessionOrPreferencesCell"
        static let ImageCell = "ImageCell"
        static let ReviewCell = "ReviewCell"
        static let ArtTopicsCell = "ArtTopicsCell"
        static let ArtCell = "ArtCell"
        static let ArtistArtCell = "ArtistArtCell"
        static let OrderNumberCell = "OrderNumberCell"
        static let TeeSizeCell = "TeeSizeCell"
        static let GalleryCell = "GalleryCell"
        static let SocialMediaCell = "SocialMediaCell"
        static let ArtTagCell = "ArtTagCell"
        static let ArtCategoryCell = "ArtCategoryCell"
        static let ArtImageCell = "ArtImageCell"
    }
}
