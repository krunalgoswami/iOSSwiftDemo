struct kRegex {
    static let SelfMatch = "SELF MATCHES %@"
    static let Email = "[A-Za-z]+[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}"
    static let Mobile = "[0-9]{4,15}"
    static let ArtSize = "[0-9]{1,5}([.]{1}[0-9]{0,2})*"
    static let ArtValue = "[0-9]{1,7}([.]{1}[0-9]{0,2})*"
    static let YoutubeIdLink = "((?<=(v|V)/)|(?<=be/)|(?<=(\\?|\\&)v=)|(?<=embed/))([\\w-]++)"
    static let Creditcard = "[0-9]{16}"
    static let Cvv = "[0-9]{3,4}"
    static let ExpiryYear = "[0-9]{4}"
    static let ExpiryMoth = "[0-9]{2}"
}
