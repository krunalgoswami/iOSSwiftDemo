struct kAlert {
    
    // Alert Titles
    struct Title {
        static let SelectSource = "Select Source"
    }
    
    // Alert Buttons
    struct Button {
        static let OK = "OK"
        static let Cancel = "Cancel"
        static let Done = "Done"
        static let Edit = "Edit"
        static let Save = "Save"
        static let Yes = "Yes"
        static let No = "No"
        static let Camera = "Camera"
        static let Library = "Library"
        static let ChangePic = "Change Pic"
        static let Delete = "Delete"
        static let ComingSoon = "Coming Soon"
        static let OutOFStock = "Out of Stock"
        static let Dropbox = "Dropbox"
        static let iCloud = "iCloud"
        static let TryAgain = "Try Again"
    }
    
    // Alert Message
    struct Message {
        static let DeleteArt = "Are you sure want to delete this Art ?"
        static let permission = "Are you sure want to delete this card ?"
        static let permissionInboxNotification = "Are you sure want to delete this notification message ?"
        static let payoutToBankOrCardAlert = "Are you sure you want to take this payout in selected card or bank?"
        static let Logout = "Are you sure you want to logout ?"
        static let failToSubScribeMessgae = "Your subsciption channel is fail."
        static let failRegisterNotificationMessgae = "You have not given permission for notification so we could not register it."
        static let fileNotSupport = "This file noy supported."
    }
}
