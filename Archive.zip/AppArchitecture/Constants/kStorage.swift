import UIKit

struct kStorage {
    static var isNetworkIssue = false
    static var isChatLive = false
    static var socketID = ""
    static var token = ""
    static var arrayCountries:[Country] = [Country]()
    static var enumRootDestination:enumRootDestinationType = .None
    static var objUser:User! = nil
//    static var socialFollowers:Int = 0
//    static var referAmount:Int = 0

    
    

    static var isBuyer = true
    static var isHomeNeedsToReload = false
    static var isUnderDeeplinkingFlow = false
    static var tektonCredit:Double = 0.00
    static var referCodeApplied = ""
    static var deepLinkParam:DeepLink = DeepLink()
}
