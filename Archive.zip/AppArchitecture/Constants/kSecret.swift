//
//  kSecret.swift
//  Tekton
//
//  Created by smartSense - 101 on 31/10/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import UIKit

struct kSecret {
    static let Bearer = "Bearer "
    static let staticToken = Bearer + "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1OTY4NzBmN2JkZTM2ZjNlZmZhNTkxYWQiLCJuYW1lIjoiTmlyYXYiLCJlbWFpbCI6Im1hamV0aGl5YS5uaXJhdjIwMTBAZ21haWwuY29tIiwicm9sZSI6InVzZXIiLCJpYXQiOjE1MDA0NTgyMzUsImV4cCI6MTUwMDQ2NTQzNX0.BfRTh5aLnRXLga0AL6NIBYkxIhkf-YLNteqt4KVdSnw"
    
    static let FB_REQUEST_PARAMETERS_DICTIONARY = ["fields":"first_name, last_name, email, picture.type(large)"]
    static let FB_READ_PERMISSIONS_ARRRAY:[Any] = ["public_profile", "email","user_friends"]
    
    static let CreativeSDKClientId = "58a83b66ae014fb28cac67908c14e6e0"//"eba9898925d54007ba7a3518bc1aab11"
    static let CreativeSDKClientSecret = "8523e959-325c-4c41-a871-f2762bab1f00"//"c8e52f47-8579-4327-a44a-2586c9931d0d"
    static let CreativeSDKRedirectURLString = "ams+279231e04c5192444a61808874882d21928f741c://adobeid/58a83b66ae014fb28cac67908c14e6e0"//"ams+4bf0923d9857a446556bfe55a848be8f51551d9e://adobeid/eba9898925d54007ba7a3518bc1aab11"
    
    static let GOOGLE_CLIENT_ID = "288497514955-psv3553b9748dupmu5m5kblgttd9t04e.apps.googleusercontent.com"
    static let GOOGLE_ACCESS_SCOPE = ["https://www.googleapis.com/auth/youtube"]
    static let GOOGLE_AUTHORIZATION_CODE = "authorization_code"
    
    static let StripPublicKey = "pk_test_7XiWSa5bLQ7UgRRcomPsaBS7"
    static let PusherKey = "8f5ff29689078862a8ee"
    static let BranchTestKey = "key_live_emvSy3pMZIvfq2Apyvrg7aegFqeTzQio"//"key_test_agtLsuZ4D4NA9EyPFWJ6tcilyqm81acf"
    static let BranchLiveKey = "key_test_heuHyYkQ1KFex6DmquCGAnhoFEeVBUpq"//"key_live_gowTCqZZy9UB4AyUC6Q9zjcatsaXKY20"
}
