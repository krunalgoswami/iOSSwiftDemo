struct kUrlApi {
    
    // MARK:- Base Url
    static let BaseUrl = "http://54.183.159.222:7778/"
   // static let BaseUrl = "http://gifkar.cloudapp.net:7778/"

    static let GetCountry = BaseUrl + "api/country"
    static let GetStripeCountry = BaseUrl + "api/stripeCountry/list"

    static var CountryFlagBaseUrl = ""//BaseUrl+"countryFlags/"
    static var BannerImagePath = ""//BaseUrl+"bannerImage/thumb/"
    static var TopicImagePath = ""//BaseUrl+"topic/thumb/"
    static var GenreImagePath = ""//BaseUrl+"genre/thumb/"
    static var ArtImagePath = ""//BaseUrl+"arts/thumb/"
    static var PruductImagePath = ""//BaseUrl+"products/thumbs/"
    static var UserProfileImagePath = ""//BaseUrl+"users/thumb/"
    
   // static let LiveChatImagePath = BaseUrl+"documents/thumb/"
    static let getUserDetail = BaseUrl+"api/user/"

    static let PostLoginWithMobile = BaseUrl + "api/loginwithmobile"
    static let PostVerifyLoginOtp = BaseUrl + "api/verifyloginotp"
    static let PostVerifySignUpOtp = BaseUrl + "api/verifysignupotp"
    static let PutVerifyOtp = BaseUrl + "api/user/verifyNumber"
    
    static let GetHomeScreen = BaseUrl + "api/homescreen"
    static let PostResendLoginOtp = BaseUrl + "api/resendloginotp"
    static let PostResendSignUpOtp = BaseUrl + "api/resendsignupotp"
    static let PostResendUserOtp = BaseUrl + "api/user/resendOtp"

    static let PostSignUp = BaseUrl + "api/signup"
    static let GetProfession = BaseUrl + "api/profession"
    static let GetTopic = BaseUrl + "api/topic"
    static let GetVideo = BaseUrl + "api/video"
    static let GetWallet = BaseUrl + "api/payout/getwalletdetails"
    static let GetPaid = BaseUrl + "api/user/stripeDetail"

    static let GetSearch = BaseUrl + "api/search/userSearch"
    static let GetPopularSearch = BaseUrl + "api/search"
    static let GetAdminDetails = BaseUrl + "api/user/getAdmin"
    
    static let GetArt = BaseUrl + "api/art"
    static let GetArtCategory = BaseUrl + "api/genre"
    static let GetAndPutArt = BaseUrl + "api/art"
    static let GetChartArt = BaseUrl + "api/artvisit/getmostvisitedarts"
    static let GetArtists = BaseUrl + "api/artvisit/getTopArtist"
    static let GetFaq = BaseUrl + "api/faq"
    static let GetPostReview = BaseUrl + "api/artRating"
    static let GetBannerImage = BaseUrl + "api/bannerImage"
    static let GetProduct = BaseUrl + "api/product"
    static let PostPromoCode = BaseUrl + "api/promoCode/applycode"

    static let PutUpdatePaymentInfo = BaseUrl + "api/user/updatePaymentInfo"
    static let PutUserProfile = BaseUrl + "api/user/updateProfile"
    static let GetCardList = BaseUrl + "api/user/getCards"
    static let PostDeletCard = BaseUrl + "api/user/deleteCard"
    static let PostDeletPayoutCard = BaseUrl + "api/user/deletePayoutCard"

    static let PostOrder = BaseUrl + "api/order"
    static let GetTektonCredit = BaseUrl + "api/user/getTektonCredit"
    static let PutUpdateMobileNumber = BaseUrl + "api/user/updateNumber"
    static let PostInstagram = BaseUrl + "api/user/instaUser"
    static let PostFacebook = BaseUrl + "api/user/fbUser"
    static let PostYouTube = BaseUrl + "api/user/youtubeUser"

    static let PostImageInLiveChat = BaseUrl + "api/chat/uploadFile"
    static let PostCustomAccount = BaseUrl + "api/user/customAccount"
    
    static let GetYoutubeAccessToken = "https://www.googleapis.com/oauth2/v4/token"
    static let GetTermsConditions = BaseUrl + "api/setting/gettermsandconditions"
    static let PutAddPayoutCard = BaseUrl + "api/user/addPayoutCard"
    static let GetDeleteNotification = BaseUrl + "api/notification"

    static let PostPayout = BaseUrl + "api/payout"


}
