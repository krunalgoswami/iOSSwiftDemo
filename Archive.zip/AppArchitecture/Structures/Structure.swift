import UIKit

struct MultipartData {
    var name:String = ""
    var key:String = ""
    var type:String = ""
    var mimeType:String = ""
    var media:Media = Media(image: UIImage())
    
    init(name: String, key: String, type: String, mimeType: String, media: Media) {
        self.name = name
        self.key = key
        self.type = type
        self.mimeType = mimeType
        self.media = media
    }
}

struct Media {
    var image:UIImage = UIImage()
    var video:NSURL = NSURL()
    var audio:NSURL = NSURL()
    var AdobeFile:Data = Data()

    
    init(image: UIImage) {
        self.image = image
    }

    init(fileData: Data) {
        self.AdobeFile = fileData
    }

    init(video: NSURL) {
        self.video = video
    }
    
    init(audio: NSURL) {
        self.audio = audio
    }
    
}
