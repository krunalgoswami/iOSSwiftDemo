//
//  LiveChatServiceSocket.swift
//  Tekton
//
//  Created by smartSense on 05/10/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import UIKit

struct LiveChatServiceSocket {
    /*
        Join Room :-
        EventName -> joinRoom
        request   -> {userId : ""}
     */
    static func joinRoom(requestData:[String:Any]) {
        SocketIOManager.sharedInstance.emiting(eventName: kSocketEvents.JoinRoom, requestData: requestData)
    }
    
    /*
     Send Message :-
     EventName -> sendMessage
     request   -> {"fromId" : "", "toId" : "", "mtype" : "", "msg" : ""}
     mtype : text, file, emojis
     
     Receive Message :-
     EventName -> receiveMessage
     response  -> {data : {msg : msgData, unreadMsgCount : unreadCount}, error : false, msg : ""}
     msgData => { msg : { __v : 0, _id : "", createdAt : "", deletedByUserId : [String], fromId : "", isEnable : Bool, isUnread : Bool, msg : "", mtype : "", toId : "", updatedAt : ""} }
     */
    static func sendMessage(requestData:[String:Any]) {
        BaseSocket.dataGoblal = MessageDataLiveChat()
        SocketIOManager.sharedInstance.emiting(eventName: kSocketEvents.SendMessage, requestData: requestData)
    }
    
    /*
        Read Message :-
        EventName -> readMessage
     	request   -> { msgId : [String] }
        response  -> data : [{ __v : 0, _id : "", createdAt : "", deletedByUserId : [String], fromId : "", isEnable : Bool, isUnread : Bool, msg : "", mtype : "", toId : "", updatedAt : ""}, error : Bool, msg : ""
     */
    static func readMessage(requestData:[String:Any]) {
        SocketIOManager.sharedInstance.emiting(eventName: kSocketEvents.ReadMessage, requestData: requestData)
    }
    
    /*
     Get Conversion :-
     EventName -> getConversion
     request   -> { pageNumber : , recordsPerPage :  toId : "" }
     response  -> {data : {msg : ChatHistory, unreadMsgCount : unreadCount}, error : false, msg : "", pager : PagerSocket() }
     ChatHistory => { chatHistory : [MsgData] }
     MsgData => { __v : 0, _id : "", createdAt : "", deletedByUserId : [String], fromId : "", isEnable : Bool, isUnread : Bool, msg : "", mtype : "", toId : "", updatedAt : ""}
     PagerSocket => { pageNumber : Int, recordsPerPage : Int, totalRecords : Int }
     */
    static func getConversion(requestData:[String:Any], showHud:Bool = false, timeOut:Bool = false) {
        SocketIOManager.sharedInstance.emiting(eventName: kSocketEvents.GetConversion, requestData: requestData, showHud: showHud, timeOut: timeOut)
    }
    
    /*
     Get Latest Msg :-
     EventName -> getLatestMsg
     request   -> { msgId : "" }
     response  -> {data : {msg : ChatHistory, unreadMsgCount : unreadCount}, error : false, msg : "", pager : PagerSocket() }
     ChatHistory => { chatHistory : [MsgData] }
     MsgData => { __v : 0, _id : "", createdAt : "", deletedByUserId : [String], fromId : "", isEnable : Bool, isUnread : Bool, msg : "", mtype : "", toId : "", updatedAt : ""}
     PagerSocket => { pageNumber : Int, recordsPerPage : Int, totalRecords : Int }
     */
    static func getLatestMsg(requestData:[String:Any], showHud:Bool = false, timeOut:Bool = false) {
        SocketIOManager.sharedInstance.emiting(eventName: kSocketEvents.GetLatestMsg, requestData: requestData, showHud: showHud, timeOut: timeOut)
    }
    
}
