//
//  ProfessionsService.swift
//  Tekton
//
//  Created by smartSense - 101 on 21/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct ProfessionsAndTopicsService {
    static func getProfessionsOrTopics(isProfession:Bool=false,Callback callback :@escaping (Base,Error?) -> Void) {
        var strUrl = ""
        if isProfession{
            strUrl = kUrlApi.GetProfession
        }else{
            strUrl = kUrlApi.GetTopic
        }
        kGeneral.networkManager.makeGetRequestToUrl(Url: strUrl, Parameters: [:], modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
}

