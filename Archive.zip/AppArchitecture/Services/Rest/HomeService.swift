//
//  HomeService.swift
//  Tekton
//
//  Created by smartSense - 101 on 21/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct HomeService {
    static func getHomeScreenData(Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = HomePayLoadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetHomeScreen, Parameters: [:], modelType: Base(), isBackOnailure: true) { (response,error) in
            if let objError = error{
                callback(Base(), objError)
            } else {
                callback(response as! Base, error)
            }
        }
    }
}
