//
//  ReviewsService.swift
//  Tekton
//
//  Created by smartSense - 101 on 28/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct ReviewsService {
    
    static func getReviewList(params:[String:Any],Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData  = ArtRattingPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetPostReview, Parameters:params, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
    
    static func submitReview(params:[String:Any],Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = CommonPayloadMessage()
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.GetPostReview, Parameters:params, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }

}
