//
//  UploadArtService.swift
//  Tekton
//
//  Created by smartSense - 101 on 29/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
struct UploadArtService {
    
    static func addArt(params:[String:Any] = [:], arrayMultipartData:[MultipartData] = [], Callback callback :@escaping (String,Error?) -> Void) {
        Base.payloadData = CommonPayloadMessage()
        kGeneral.networkManager.makePostMultipartRequestToUrl(Url: kUrlApi.GetAndPutArt, Parameters: params, ArrayMultipartData: arrayMultipartData, modelType: Base(), showHud:false, isBackOnailure: true, Callback: { (response, error) in
            if let objError = error{
                callback("", objError)
            } else {
                callback(((response as! Base).payload as! CommonPayloadMessage).message, error)
            }
        })
    }
}
