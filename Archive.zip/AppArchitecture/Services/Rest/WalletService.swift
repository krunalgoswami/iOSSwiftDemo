//
//  GetWalletService.swift
//  Tekton
//
//  Created by smartSense - 101 on 12/10/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
struct WalletService {
    static func getWalletDetail(Callback callback :@escaping (Wallet,Error?) -> Void) {
        Base.payloadData = WalletPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetWallet, Parameters:[:], modelType: Base(), isBackOnailure: true) { (response,error) in
            if let objError = error{
                callback(Wallet(), objError)
            } else {
                callback(((response as! Base).payload as! WalletPayloadData).data, error)
            }
        }
    }
    
    static func getStripeDetail(Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = GetPaidWalletPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetPaid, Parameters:[:], modelType: Base()) { (response,error) in
            callback((response as! Base), error)
        }
    }
}
