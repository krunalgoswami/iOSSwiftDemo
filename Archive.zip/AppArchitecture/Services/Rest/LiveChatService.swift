//
//  LiveChatService.swift
//  Tekton
//
//  Created by smartSense on 10/10/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import UIKit

class LiveChatService: NSObject {
    static func uploadImage(arrayMultipartData:[MultipartData], Callback callback :@escaping (String,Error?) -> Void) {
        Base.payloadData = LiveChatPayloadData()
        kGeneral.networkManager.makePostMultipartRequestToUrl(Url: kUrlApi.PostImageInLiveChat, Parameters: [:], ArrayMultipartData: arrayMultipartData, modelType: Base(), Callback: { (response, error) in
            callback(((response as! Base).payload as! LiveChatPayloadData).data, error)
        })
    }
}
