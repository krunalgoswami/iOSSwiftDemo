//
//  BannerImageService.swift
//  Tekton
//
//  Created by smartSense - 101 on 26/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import UIKit
import AlamofireJsonToObjects

struct BannerImageService {

    static func getBannerImageList(params:[String:Any],isShowHud:Bool=true,Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = BannerImagePayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetBannerImage, Parameters:params, modelType: Base(),showHud:isShowHud) { (response,error) in
            callback(response as! Base, error)
        }
    }

}
