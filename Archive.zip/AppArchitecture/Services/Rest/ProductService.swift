//
//  ProductService.swift
//  Tekton
//
//  Created by smartSense - 101 on 26/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct ProductService {
    static func getProductList(params:[String:Any],Callback callback :@escaping ([Product],Error?) -> Void) {
        Base.payloadData = ProductPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetProduct, Parameters: params, modelType: Base()) { (response,error) in
            if let objProductPayloadData = (response as! Base).payload as? ProductPayloadData{
                let productArray = objProductPayloadData.data
                kUrlApi.PruductImagePath = objProductPayloadData.basePath
                callback(productArray, error)
            }
        }
    }
    
    static func addOrder(params:[String:Any], Callback callback :@escaping (AddOrder,Error?) -> Void) {
        Base.payloadData = AddOrderPayloadData()
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostOrder, Parameters: params, modelType: Base()) { (response,error) in
            if let objAddOrderPayloadData = (response as! Base).payload as? AddOrderPayloadData{
                callback(objAddOrderPayloadData.data, error)
            } else {
                print("------> ERROR IN MODEL ADD ORDER.")
            }
        }
    }
    
    static func getOrderTrackingList(params:[String:Any],Callback callback :@escaping ([Order],Error?) -> Void) {
        Base.payloadData = OrderPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.PostOrder, Parameters: params, modelType: Base()) { (response,error) in
            let productArray = ((response as! Base).payload as! OrderPayloadData).data
            callback(productArray, error)
        }
    }
    
    static func getOrderList(params:[String:Any],Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = OrderPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.PostOrder, Parameters: params, modelType: Base()) { (response,error) in
            callback((response as! Base), error)
        }
    }
    
    static func getSaleOrderList(params:[String:Any],Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = OrderPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.PostOrder, Parameters: params, modelType: Base()) { (response,error) in
            callback((response as! Base), error)
        }
    }
}
