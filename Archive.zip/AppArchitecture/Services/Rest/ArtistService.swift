//
//  ArtistService.swift
//  Tekton
//
//  Created by smartSense - 101 on 23/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct ArtistService {
    static func getArtistsList(Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = ArtistPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetArtists, Parameters:[:], modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }

    static func getArtListOfArtist(param:[String:Any],Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = ArtPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetAndPutArt, Parameters:param, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
    
    static func getArtListOfArtistMonthlyViews(param:[String:Any],Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = ArtistPayloadData()

        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetArtists, Parameters:param, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }

}
