//
//  SearchProductService.swift
//  Tekton
//
//  Created by smartSense - 101 on 12/10/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
struct SearchProductService {
    static func getSearchProduct(params:[String:Any],Callback callback :@escaping ([SearchProduct],Error?) -> Void) {
        Base.payloadData = SearchProductPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetSearch, Parameters:params, modelType: Base()) { (response,error) in
            callback(((response as! Base).payload as! SearchProductPayloadData).data, error)
        }
    }
    
    static func getPopularSearchProduct(Callback callback :@escaping ([PopularSearchData],Error?) -> Void) {
        Base.payloadData = PopularSearchProductPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetPopularSearch, Parameters:[:], modelType: Base(), isBackOnailure: true) { (response,error) in
            if let objError = error{
                callback([], objError)
            } else {
                callback(((response as! Base).payload as! PopularSearchProductPayloadData).data, error)
            }
        }
    }
}
