//
//  ChartService.swift
//  Tekton
//
//  Created by smartSense - 101 on 23/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct ChartService {
    static func getChartList(Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = ChartPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetChartArt, Parameters:[:], modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
}
