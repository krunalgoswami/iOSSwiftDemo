//
//  ArtService.swift
//  Tekton
//
//  Created by smartSense - 101 on 22/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct ArtService {
    static func getArtList(params:[String:Any],Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData  = ArtPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetAndPutArt, Parameters:params, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
    
    static func getArtDetail(artId:String, params:[String:Any], Callback callback :@escaping (Base,Error?) -> Void) {
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetAndPutArt+"/"+artId, Parameters:params, modelType: Base(), isBackOnailure: true) { (response,error) in
            if let _ = error{
                callback(Base(), error)
            } else {
                callback(response as! Base, error)
            }
        }
    }

    static func deleteArt(artId:String, Callback callback :@escaping (String,Error?) -> Void) {
        Base.payloadData  = CommonPayloadMessage()
        
        kGeneral.networkManager.makeDeleteRequestToUrl(Url: "\(kUrlApi.GetAndPutArt)/\(artId)/0", Parameters:[:], modelType: Base()) { (response,error) in
            callback(((response as! Base).payload as! CommonPayloadMessage).message, error)
        }
    }

}
