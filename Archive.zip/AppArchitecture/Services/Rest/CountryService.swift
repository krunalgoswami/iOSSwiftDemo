//
//  CountryService.swift
//  Tekton
//
//  Created by smartSense - 101 on 21/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct CountryService {
    static func getCountryList(params:[String:Any], Callback callback :@escaping (Base,Error?) -> Void) {
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetCountry, Parameters: params, modelType: Base()) { (response,error) in
            let objBase = response as! Base
            Utility.countryTotalRecords = objBase.pager.totalRecords
            Utility.countTotalPage(totalRecords: Utility.countryTotalRecords)
            callback(objBase, error)
        }
    }
    
    static func getCountryList(Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = CountryPayLoadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetCountry, Parameters: [:], modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
    
    static func getCountryDetail(countryId:String,Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = CountryPayLoadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetCountry+"/"+countryId, Parameters: [:], modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
    
    static func getStripeCountryList(params:[String:Any], Callback callback :@escaping ([StripeCountry],Error?) -> Void) {
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetStripeCountry, Parameters: params, modelType: Base()) { (response,error) in
            let objBase = response as! Base
            Utility.countryTotalRecords = objBase.pager.totalRecords
            Utility.countTotalPage(totalRecords: Utility.countryTotalRecords)
            callback(((response as! Base).payload as! StripeCountryPayLoadData).data, error)
        }
    }
    
}
