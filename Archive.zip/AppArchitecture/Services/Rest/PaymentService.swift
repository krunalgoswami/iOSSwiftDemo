//
//  PaymentService.swift
//  Tekton
//
//  Created by smartSense - 101 on 26/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct PaymentService {
    static func addPaymentCard(isPayment:Bool=false,params:[String:Any],Callback callback :@escaping (Base,Error?) -> Void) {
        if isPayment{
            Base.payloadData = CommonPayloadMessage()
        }else{
            Base.payloadData = AddCardPayloadMessageData()
        }
        kGeneral.networkManager.makePutRequestToUrl(Url: kUrlApi.PutUpdatePaymentInfo, Parameters: params, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
}
