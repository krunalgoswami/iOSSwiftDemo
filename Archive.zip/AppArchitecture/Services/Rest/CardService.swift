//
//  CardService.swift
//  Tekton
//
//  Created by smartSense - 101 on 29/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct CardService {
    static func getCardList(Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData =  CardInfoPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetCardList, Parameters: [:], modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
    
    static func getPayoutCardList(params:[String:Any] = [:],Callback callback :@escaping ([PayoutCardInfoData],Error?) -> Void) {
        Base.payloadData =  PayoutInfoPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetCardList, Parameters: params, modelType: Base()) { (response,error) in
            callback(((response as! Base).payload as! PayoutInfoPayloadData).data, error)
        }
    }

    static func deleteCard(params:[String:Any] = [:],Callback callback :@escaping (String,Error?) -> Void) {
        Base.payloadData =  CommonPayloadMessage()
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostDeletCard, Parameters: params, modelType: Base()) { (response,error) in
            callback((response as! Base).message, error)
        }
    }

    static func deletePayoutCard(params:[String:Any] = [:],Callback callback :@escaping (String,Error?) -> Void) {
        Base.payloadData =  CommonPayloadMessage()
        kGeneral.networkManager.makeDeleteRequestToUrl(Url: kUrlApi.PostDeletPayoutCard, Parameters: params, modelType: Base()) { (response,error) in
            callback((response as! Base).message, error)
        }
    }

}
