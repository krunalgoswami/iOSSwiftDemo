//
//  VideoService.swift
//  Tekton
//
//  Created by smartSense - 101 on 22/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct VideoService {
    static func getVideoList(params:[String:Any],Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = VideoPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetVideo, Parameters:params, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
}
