//
//  TektonCreditService.swift
//  Tekton
//
//  Created by smartSense - 101 on 30/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
struct TektonCreditService {
    static func getTektonCredit(Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData =  TektonCreditPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetTektonCredit, Parameters: [:], modelType: Base(),showHud:true) { (response,error) in
            callback(response as! Base, error)
        }
    }
}
