import UIKit
import AlamofireJsonToObjects

struct AuthenticationService {
    static func login(params:[String:Any], Callback callback :@escaping (Base,Error?) -> Void) {
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostLoginWithMobile, Parameters: params, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
    
    static func verifyOtp(urlString:String,params:[String:Any], Callback callback :@escaping (Base,Error?) -> Void) {
        kGeneral.networkManager.makePostRequestToUrl(Url: urlString, Parameters: params, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }

    static func resendOtp(urlString:String,params:[String:Any], Callback callback :@escaping (Base,Error?) -> Void) {
        kGeneral.networkManager.makePostRequestToUrl(Url: urlString, Parameters: params, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
    
    static func signUp(params:[String:Any], Callback callback :@escaping (Base,Error?) -> Void) {
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostSignUp, Parameters: params, modelType: Base()) { (response,error) in
            callback(response as! Base, error)
        }
    }
}
