//
//  TopicsService.swift
//  Tekton
//
//  Created by smartSense - 101 on 21/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
import AlamofireJsonToObjects

struct TopicsService {
    static func getTopics(params:[String:Any] = [:], Callback callback :@escaping ([TopicOrArtCategory],Error?) -> Void) {
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetTopic, Parameters: params, modelType: Base()) { (response,error) in
            let objBase = response as! Base
            Utility.countTotalPage(totalRecords: objBase.pager.totalRecords)
            callback((objBase.payload as! TopicOrArtCategoryPayloadData).data, error)
        }
    }
}
