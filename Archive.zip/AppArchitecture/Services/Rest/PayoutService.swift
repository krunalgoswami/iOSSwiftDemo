//
//  PayoutService.swift
//  Tekton
//
//  Created by smartSense - 101 on 30/10/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
struct PayoutService {

    static func AddBankAccountDetail(params:[String:Any] = [:], arrayMultipartData:[MultipartData] = [], Callback callback :@escaping (Base,Error?) -> Void) {
        Base.payloadData = CustomPayoutAccountPayloadData()
        if arrayMultipartData.count != 0{
            kGeneral.networkManager.makePostMultipartRequestToUrl(Url: kUrlApi.PostCustomAccount, Parameters: params, ArrayMultipartData: arrayMultipartData, modelType: Base(), Callback: { (response, error) in
                callback((response as! Base), error)
            })
        } else {
            kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostCustomAccount, Parameters: params, modelType: Base(), Callback: { (response, error) in
                callback((response as! Base), error)
            })
        }
    }
    
    static func payoutToBank(params:[String:Any], Callback callback :@escaping (String,Error?) -> Void) {
        Base.payloadData = CommonPayloadMessage()
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostPayout, Parameters:params, modelType: Base()) { (response,error) in
            callback(((response as! Base).payload as! CommonPayloadMessage).message, error)
        }
    }

}
