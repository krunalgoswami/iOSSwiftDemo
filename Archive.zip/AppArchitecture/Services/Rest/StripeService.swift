//
//  StripeService.swift
//  Tekton
//
//  Created by smartSense - 101 on 01/11/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
struct StripeService {
    static func addBankOnStripe(params:[String:Any],Callback callback :@escaping ([CardsInfo],Error?) -> Void) {
        Base.payloadData = AddPayoutCardPayloadData()
        kGeneral.networkManager.makePutRequestToUrl(Url: kUrlApi.PutAddPayoutCard, Parameters:params, modelType: Base()) { (response,error) in
            callback(((response as! Base).payload as! AddPayoutCardPayloadData).data, error)
        }
    }
}
