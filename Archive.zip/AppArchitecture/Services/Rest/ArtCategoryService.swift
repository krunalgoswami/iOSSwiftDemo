//
//  ArtCategoryService.swift
//  Tekton
//
//  Created by smartSense on 28/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import UIKit

struct ArtCategoryService {
    static func getArtCategoryList(params:[String:Any], Callback callback :@escaping ([TopicOrArtCategory],Error?) -> Void) {
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetArtCategory, Parameters: params, modelType: Base()) { (response,error) in
            let objBase = (response as! Base)
            Utility.countTotalPage(totalRecords: objBase.pager.totalRecords)
            callback((objBase.payload as! TopicOrArtCategoryPayloadData).data, error)
        }
    }
}
