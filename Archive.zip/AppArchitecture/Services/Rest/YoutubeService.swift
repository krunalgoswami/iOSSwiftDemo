//
//  YoutubeService.swift
//  Tekton
//
//  Created by smartSense - 101 on 30/10/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import UIKit

struct YoutubeService {
    static func getSearchProduct(params:[String:Any],Callback callback :@escaping ([SearchProduct],Error?) -> Void) {
        Base.payloadData = SearchProductPayloadData()
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.GetYoutubeAccessToken, Parameters:params, modelType: Base()) { (response,error) in
            callback(((response as! Base).payload as! SearchProductPayloadData).data, error)
        }
    }
}
