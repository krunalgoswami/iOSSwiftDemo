//
//  NotificationService.swift
//  Tekton
//
//  Created by smartSense - 101 on 02/11/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import Foundation
struct NotificationService {
    static func getNotification(params:[String:Any],Callback callback :@escaping ([Notification],Error?) -> Void) {
        Base.payloadData = NotificationPayloadData()
        kGeneral.networkManager.makeGetRequestToUrl(Url: kUrlApi.GetDeleteNotification, Parameters:params, modelType: Base()) { (response,error) in
            if let objNotificationPayloadData = (response as! Base).payload as? NotificationPayloadData{
                callback(objNotificationPayloadData.data, error)
            }
        }
    }
    
    static func deleteMessage(notificationId:String,Callback callback :@escaping (String,Error?) -> Void) {
        Base.payloadData =  CommonPayloadMessage()
        kGeneral.networkManager.makeDeleteRequestToUrl(Url: kUrlApi.GetDeleteNotification+"/"+notificationId+"/false", Parameters: [:], modelType: Base()) { (response,error) in
            callback((response as! Base).message, error)
        }
    }
}
