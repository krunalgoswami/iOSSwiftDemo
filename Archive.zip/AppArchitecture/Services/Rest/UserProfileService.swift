//
//  UserProfileService.swift
//  Tekton
//
//  Created by smartSense on 26/09/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import UIKit

struct UserProfileService {
    static func updateProfile(params:[String:Any] = [:], arrayMultipartData:[MultipartData] = [], Callback callback :@escaping (User,Error?) -> Void) {
        Base.payloadData = UserProfilePayloadData()
        if arrayMultipartData.count != 0{
            kGeneral.networkManager.makePutMultipartRequest(Url: kUrlApi.PutUserProfile, Parameters: params, ArrayMultipartData: arrayMultipartData, modelType: Base(), Callback: { (response, error) in
                let objBase = response as! Base
                Utility.showToastMessage(objBase.message)
                callback((objBase.payload as! UserProfilePayloadData).data, error)
            })
        } else {
            kGeneral.networkManager.makePutRequestToUrl(Url: kUrlApi.PutUserProfile, Parameters: params, modelType: Base()) { (response, error) in
                let objBase = response as! Base
                Utility.showToastMessage(objBase.message)
                callback((objBase.payload as! UserProfilePayloadData).data, error)
            }
        }
    }

    static func updateMobileNumber(params:[String:Any], Callback callback :@escaping (String,Error?) -> Void) {
        Base.payloadData = LoginPayloadData()
        kGeneral.networkManager.makePutRequestToUrl(Url: kUrlApi.PutUpdateMobileNumber, Parameters: params, modelType: Base()) { (response,error) in
//            callback(((response as! Base).payload as! LoginPayloadData).data.otp, error)
            callback((response as! Base).message, error)
        }
    }

    static func verifyOtp(params:[String:Any], Callback callback :@escaping (UserMobile,Error?) -> Void) {
        Base.payloadData = UserMobilePayload()
        kGeneral.networkManager.makePutRequestToUrl(Url: kUrlApi.PutVerifyOtp, Parameters: params, modelType: Base()) { (response,error) in
            let objBase = response as! Base
            Utility.showToastMessage(objBase.message)
            callback((objBase.payload as! UserMobilePayload).data, error)
        }
    }
    
    static func resendOtp(params:[String:Any], Callback callback :@escaping (String,Error?) -> Void) {
        Base.payloadData = OtpPayLoadData()
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostResendUserOtp, Parameters: params, modelType: Base()) { (response,error) in
//            callback(((response as! Base).payload as! OtpPayLoadData).data.otp, error)
            callback((response as! Base).message, error)

        }
    }
    
}
