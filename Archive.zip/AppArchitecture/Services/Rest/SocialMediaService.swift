//
//  SocialMediaService.swift
//  Tekton
//
//  Created by smartSense - 101 on 04/10/17.
//  Copyright © 2017 smartSense. All rights reserved.
//

import AlamofireJsonToObjects

struct SocialMediaService {
    static func instagramConnect(params:[String:Any] = [:],Callback callback :@escaping (Instagram,Error?) -> Void) {
        Base.payloadData =  InstagramPayloadData()
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostInstagram, Parameters: params, modelType: Base()) { (response,error) in
            Utility.checkIsBuyerSeller(isSeller: ((response as! Base).payload as! InstagramPayloadData).isSeller)
            callback(((response as! Base).payload as! InstagramPayloadData).data, error)
        }
    }
    
    static func facebookConnect(params:[String:Any] = [:],Callback callback :@escaping (Friends,Error?) -> Void) {
        Base.payloadData =  FacebookPayloadData()
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostFacebook, Parameters: params, modelType: Base()) { (response,error) in
            Utility.checkIsBuyerSeller(isSeller: ((response as! Base).payload as! FacebookPayloadData).isSeller)
            callback(((response as! Base).payload as! FacebookPayloadData).data.friends, error)
        }
    }
    
    static func youTubeConnect(params:[String:Any] = [:],Callback callback :@escaping (YouTubeSubscribers,Error?) -> Void) {
        Base.payloadData =  YouTubePayloadData()
        kGeneral.networkManager.makePostRequestToUrl(Url: kUrlApi.PostYouTube, Parameters: params, modelType: Base()) { (response,error) in
            Utility.checkIsBuyerSeller(isSeller: ((response as! Base).payload as! YouTubePayloadData).isSeller)
            callback(((response as! Base).payload as! YouTubePayloadData).data, error)
        }
    }
    
}
